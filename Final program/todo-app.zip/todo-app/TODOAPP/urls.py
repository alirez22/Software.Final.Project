
from django.contrib import admin
from django.urls import path, include, re_path
from rest_framework.schemas import get_schema_view
from rest_framework_swagger.renderers import OpenAPIRenderer, SwaggerUIRenderer



schema_view = get_schema_view(
    title='TODO API',
    renderer_classes=[OpenAPIRenderer,SwaggerUIRenderer]
)

urlpatterns = [

    path('admin/', admin.site.urls),
    path('user/',include('user.urls')),
    path('todo/',include('todo.urls')),
    path('msg/',include('msg.urls')),
    path('group/', include('group_todo.urls')),

    re_path(r'^$', schema_view),
]
