
from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient

from django.contrib.auth.models import User


class RegisterTesting(TestCase):

    client = APIClient()

    def setUp(self) -> None:
        self.response = self.client.post('/user/register/', {
            'username': 'abolfazl4359085',
            'password': 'ghtuddgnds1334',
            'first_name': 'abolfazl',
            'last_name': 'andalib',
            'email': 'abolfazlandalib@gmail.com'

        }, format='json')

    def test_single_register_ok(self):


        self.assertEqual(self.response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.filter(username = 'abolfazl4359085').count(), 1)

    def test_single_register_not_ok(self):

        self.unsuccess_response_username = self.client.post('/user/register/', {
            'username': 'abolfazl435',
            'password': 'ghtuddgnds1334',
            'first_name': 'abolfazl',
            'last_name': 'andalib',
            'email': 'abolfazlandalib@gmail.com'

        }, format='json')

        self.unsuccess_response_password = self.client.post('/user/register/', {
            'username': 'abolfazl',
            'password': 'ghtuddgnds',
            'first_name': 'abolfazl',
            'last_name': 'andalib',
            'email': 'abolfazlandalib@gmail.com'

        }, format='json')

        self.assertEqual(self.unsuccess_response_username.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.filter(username='abolfazl435').count(), 1)

        self.assertEqual(self.unsuccess_response_password.status_code, status.HTTP_201_CREATED)
        self.assertEqual(User.objects.filter(username='abolfazl').count(), 1)



class AuthTesting(TestCase):
    client = APIClient()
    refresh_token = ''
    def setUp(self):
        self.username = 'abolfazl4359085'
        self.user = User.objects.create_user(username=self.username,
                                             email='abolfazlandalib@gmail.com',
                                             password='ghtuddgnds1334',
                                             first_name = 'abolfazl',
                                             last_name = 'andalib')
    def test_access_ok(self):
        response = self.client.post('/user/api/token/', {
            'username':'abolfazl4359085',
            'password':'ghtuddgnds1334',

        }, format='json')
        self.refresh_token = response.data["refresh"]
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_access_not_ok_username_and_pass_wrong(self):
        response = self.client.post('/user/api/token/', {
            'username':'abolfazl435ff9085',
            'password':'ghtuddgnds1gd334',

        }, format='json')

        self.assertNotEqual(response.status_code, status.HTTP_200_OK)

    def test_refresh_ok(self):
        response = self.client.post('/user/api/token/', {
            'username': 'abolfazl4359085',
            'password': 'ghtuddgnds1334',

        }, format='json')

        response_1 = self.client.post('/user/api/token/refresh/', {
            'refresh':response.data['refresh']

        }, format='json')

        self.assertEqual(response_1.status_code, status.HTTP_200_OK)








class GetInfoTesting(TestCase):
    client = APIClient()

    def setUp(self):
        self.username = 'abolfazl4359085'
        self.user = User.objects.create_user(username=self.username,
                                             email='abolfazlandalib@gmail.com',
                                             password='ghtuddgnds1334',
                                             first_name='abolfazl',
                                             last_name='andalib')

        response = self.client.post('/user/api/token/', {
            'username': 'abolfazl4359085',
            'password': 'ghtuddgnds1334',

        }, format='json')

        self.access_token = response.data["access"]

    def test_get_info_ok(self):


        get_info = self.client.get('/user/get_info/' ,HTTP_AUTHORIZATION= 'Bearer ' + self.access_token)
        self.assertEqual(get_info.status_code, 200)


class DeActivateTesting(TestCase):

    client = APIClient()
    access_token = ''

    def setUp(self) -> None:

            self.username = 'abolfazl4359085'
            self.user = User.objects.create_user(username=self.username,
                                                 email='abolfazlandalib@gmail.com',
                                                 password='ghtuddgnds1334',
                                                 first_name='abolfazl',
                                                 last_name='andalib')

            response = self.client.post('/user/api/token/', {
                'username': 'abolfazl4359085',
                'password': 'ghtuddgnds1334',

            }, format='json')

            self.access_token = response.data["access"]

    def test_pass_deactive(self):
        deactive = self.client.post('/user/deactive/', HTTP_AUTHORIZATION='Bearer ' + self.access_token)
        self.assertEqual(deactive.status_code, 200)








class ActivateTesting(TestCase):
    def test_pass_active(self):
        pass




class UpdateTesting(TestCase):
    def setUp(self) -> None:
        pass

    def test_pass_update(self):
        pass




class ChangePasswordTesting(TestCase):

    client = APIClient()

    def setUp(self) -> None:
        response = self.client.post('/user/api/token/', {'username': 'abolfazl832','password': 'ghurgegrhfe4'}, format='json')

        self.token = response.data['access']

    def test_change_pass(self):
        data = {'old_password':'ghurgegrhfe4',
                'new_password':'ghghgh12345678'}

        response = self.client.put('/user/api/change-password/',
                                    data=data,
                                    HTTP_AUTHORIZATION='Bearer ' + self.token, content_type='application/json')
        self.assertEqual(response.status_code, 200)








