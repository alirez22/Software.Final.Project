from django.urls import path
from rest_framework_simplejwt import views as jwt_views
from user.views import Register, Update, DeActivate, GetInfo, Activate, ChangePasswordView

urlpatterns = [
    path('register/', Register.as_view()),
    path('api/token/', jwt_views.TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
    path('update/', Update.as_view()),
    path('deactive/', DeActivate.as_view()),
    path('active/', Activate.as_view()),
    path('get_info/', GetInfo.as_view()),
    path('api/change-password/', ChangePasswordView.as_view(), name='change-password'),
]