from django.http import JsonResponse
from drf_yasg.utils import swagger_auto_schema
from rest_framework import permissions, status
from rest_framework.generics import CreateAPIView, UpdateAPIView, RetrieveAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.contrib.auth.models import User
from user.queries import *
from user.serializers import UserSerializer, ChangePasswordSerializer


class Register(CreateAPIView):

    model = User
    permission_classes = [permissions.AllowAny]
    serializer_class = UserSerializer

    def post(self, request, *args, **kwargs):
        return q_1(self,request)





class Update(UpdateAPIView):

    permission_classes = [permissions.IsAuthenticated]
    serializer_class = UserSerializer

    def get_object(self):
        user = self.request.user
        obj = User.objects.get(id = user.id)
        return obj

    def update(self, request, *args, **kwargs):
        return q_2(self,request)




class GetInfo(RetrieveAPIView):

    permission_classes  = [IsAuthenticated]
    serializer_class = UserSerializer


    def retrieve(self, request, *args, **kwargs):
        return q_3(self,request)


class DeActivate(APIView):

    def post(self, request, format = None):
        return q_4(self,request)



class Activate(APIView):

    def post(self, request, format = None):
       return q_5(self,request)


class ChangePasswordView(UpdateAPIView):

    serializer_class = ChangePasswordSerializer
    model = User
    permission_classes = (IsAuthenticated,)

    def get_object(self, queryset=None):
        obj = self.request.user
        return obj

    def update(self, request, *args, **kwargs):
        return q_6(self,request)
