from django.http import JsonResponse
from rest_framework import status

from django.contrib.auth.models import User


def q_1(self, request):
    data = request.data
    try:
        print("SALAM")
        serializer = self.serializer_class(data=data)
        print("SALAM2")
        serializer.is_valid(raise_exception=True)
        print("SALAM3")
        serializer.save()
        print("SALAM4")
        return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
    except Exception:
        return JsonResponse({'error': 'duplicate username used!'}, status=500)

def q_2(self, request):
    data = request.data
    instance = self.get_object()
    instance.username = data.get('username', instance.username)
    instance.first_name = data.get('first_name', instance.first_name)
    instance.last_name = data.get('last_name', instance.last_name)
    instance.email = data.get('email', instance.email)

    d = {
        'username': instance.username,
        'first_name': instance.first_name,
        'last_name': instance.last_name,
        'email': instance.email
    }
    print(d)
    serializer = self.get_serializer(instance, data=d, partial=True)

    serializer.is_valid(raise_exception=True)

    self.perform_update(serializer)

    return JsonResponse(serializer.data, status=200)

def q_3(self, request):
    try:
        user = request.user
        instance = self.serializer_class(user)
        return JsonResponse(instance.data, status=status.HTTP_200_OK)
    except Exception as e:

        return JsonResponse({'error': 'jwt expired or not active!'}, status=500)

def q_4(self, request):
    user = request.user

    if not user:
        return JsonResponse({'msg': 'problem with authentication'}, status=401)
    id = user.id
    object = User.objects.get(id=id)
    object.is_active = False
    object.save()
    return JsonResponse({'msg': 'de activated'}, status=200)

def q_5(self, request):

    data = request.data
    username = data.get('username')
    password = data.get('password')
    try:
        user = User.objects.get(username=username)
        if not user.check_password(password):
            return JsonResponse({'msg': 'password is wrong!'}, status=400)
        user.is_active = True
        user.save()
        return JsonResponse({'msg': 'activated!'}, status=200)
    except Exception:
        return JsonResponse({'error': 'it seems this account has been removed from database!'}, status=404)

def q_6(self, request):
    self.object = self.get_object()
    serializer = self.get_serializer(data=request.data)

    if serializer.is_valid():
        # Check old password
        if not self.object.check_password(serializer.data.get("old_password")):
            return JsonResponse({"old_password": ["Wrong password."]}, status=status.HTTP_400_BAD_REQUEST)
        # set_password also hashes the password that the user will get
        self.object.set_password(serializer.data.get("new_password"))
        self.object.save()
        response = {
            'status': 'success',
            'code': status.HTTP_200_OK,
            'message': 'Password updated successfully',

        }

        return JsonResponse(response)

    return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)