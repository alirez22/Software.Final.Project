from django.apps import AppConfig


class GroupTodoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'group_todo'
