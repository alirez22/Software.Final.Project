from django.urls import path
from .views import *

urlpatterns = [
    path('create/', CreateGroupAPIView.as_view()),
    path('my_group/', MyGroupsListRecieve.as_view()),
    path('info/',MySingleGroupInfo.as_view()),
    path('add_member/',AddMemberToGroupByAdmin.as_view()),
    path('remove/',RemoveMemberFromGroupByAdmin.as_view()),
    path('active/',ActivateGroup.as_view()),
    path('deactive/',DeActiveGroup.as_view()),
    path('destroy/', DestroyGroup.as_view()),
    path('new_todo/',CreateTODOobjectInGroup.as_view()),
    path('get_todo_list/',GetListOfTODO.as_view()),
    path('get_todo_object/',GetOneTODO.as_view()),
    path('update_todo/',UpdateTODO.as_view()),
    path('delete_todo/',DeleteTODO.as_view()),
    path('done_todo/',DoneTODO.as_view()),
    path('members/', GetGroupMembers.as_view())

]
