from rest_framework import serializers

from todo.models import TODO
from todo.serializers import TODOSerializer
from django.contrib.auth.models import User
from .models import Group, Member, GroupTODO


class MemberCreateSerializer(serializers.ModelSerializer):
    member = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    group = serializers.PrimaryKeyRelatedField(queryset=Group.objects.all())
    class Meta:
        model = Member
        fields = ['member','group']


class GroupCreateSerializer(serializers.ModelSerializer):

    admin = serializers.PrimaryKeyRelatedField(queryset = User.objects.all())
    group_name = serializers.CharField(max_length = 100)
    group_category = serializers.CharField(max_length = 100)

    class Meta:
        model = Group
        fields = ['id','admin','group_name', 'group_category']

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username','first_name','last_name','email','is_active']

class GroupSerializier(serializers.ModelSerializer):
    admin = UserSerializer()
    class Meta:
        model = Group
        fields = '__all__'


class GroupListSerializer(serializers.ModelSerializer):

    group = GroupSerializier()

    class Meta:
        model = Member
        fields = ['group']

###################################################################################

class CreateTODOSerializer(serializers.ModelSerializer):
    group = serializers.PrimaryKeyRelatedField(queryset=Group.objects.all())
    todo  = serializers.PrimaryKeyRelatedField(queryset=TODO.objects.all())
    class Meta:
        model = GroupTODO
        fields = ['id','group','todo']



class TODOGetInGroupSerialzier(serializers.ModelSerializer):
    owner = UserSerializer()
    class Meta:
        model = TODO
        fields = '__all__'

class RecieveGroupTODOSerializer(serializers.ModelSerializer):

    todo = TODOGetInGroupSerialzier()

    class Meta:
        model = GroupTODO
        fields = ['id','todo']



class GroupMemberRecieveSerializer(serializers.ModelSerializer):
    member = UserSerializer()
    class Meta:
        model = Member
        fields = ['member']






































