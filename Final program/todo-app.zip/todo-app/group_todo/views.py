import datetime

from django.http import JsonResponse
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.generics import CreateAPIView, UpdateAPIView, RetrieveAPIView, DestroyAPIView, ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from msg.serializers import SaveNotificationSerializer
from todo.models import TODO
from todo.views import Submit
from .models import Member
from .permissions.is_admin import IsGroupAdmin

from .queries.ActivateGroup import post_4
from .queries.CreateTODOobjectInGroup import post_5
from .queries.DeActiveGroup import post_3
from .queries.DeleteTODO import get_todo_object_id_2, get_object_2
from .queries.DoneTODO import get_todo_object_id_3, get_object_3, post_6
from .queries.GetGroupMembers import get_queryset_2
from .queries.GetListOfTODO import get_queryset_3, get_2
from .queries.GetOneTODO import get_queryset_4, get_3
from .queries.UpdateTODO import get_todo_object_id_1, get_object_1, update_1
from .serializers import *
from .queries.CreateGroupAPIView import *
from .queries.MyGroupsListRecieve import *
from .queries.MySingleGroupInfo import *
from .queries.AddMemberToGroupByAdmin import *
from .queries.RemoveMemberFromGroupByAdmin import *
from .queries.DestroyGroup import *
##################################################################################################


class CreateGroupAPIView(CreateAPIView):

    serializer_class = GroupCreateSerializer
    permission_classes = [IsAuthenticated,]


    def post(self, request, *args, **kwargs):
       return post_1(self, request, *args, **kwargs)


#tested
class MyGroupsListRecieve(ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = GroupListSerializer

    def get_queryset(self):
        return get_queryset_1(self)



#tested
class MySingleGroupInfo(RetrieveAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = GroupListSerializer

    def get(self,request):
        return get_1(self,request)


class AddMemberToGroupBySelf(CreateAPIView):
    pass

#tested
class AddMemberToGroupByAdmin(CreateAPIView):
    permission_classes = [IsAuthenticated & IsGroupAdmin]
    serializer_class = MemberCreateSerializer
    def post(self, request, *args, **kwargs):
       return post_2(self, request, *args, **kwargs)



#tested
class RemoveMemberFromGroupByAdmin(DestroyAPIView):

    permission_classes = [IsAuthenticated & IsGroupAdmin]

    def destroy(self, request, *args, **kwargs):
        return destroy_1(self, request, *args, **kwargs)



#tested
class DestroyGroup(DestroyAPIView):

    permission_classes = [IsAuthenticated & IsGroupAdmin]

    def destroy(self, request, *args, **kwargs):
        return destroy_2(self, request, *args, **kwargs)



#########3flag

#tested
class DeActiveGroup(APIView):

    permission_classes = [IsGroupAdmin & IsAuthenticated]

    def post(self, format = None):
        return post_3(self, format = None)


#tested
class ActivateGroup(APIView):

    permission_classes = [IsGroupAdmin & IsAuthenticated]

    def post(self, format=None):
        return post_4(self, format=None)


#tested
class GetGroupMembers(ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = GroupMemberRecieveSerializer

    def get_queryset(self):
        return get_queryset_2(self)


#################################################################################################################

#tested
class CreateTODOobjectInGroup(Submit):

    serializer_class = CreateTODOSerializer
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        return post_5(self, request, *args, **kwargs)


#tested
class GetListOfTODO(ListAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = RecieveGroupTODOSerializer

    def get_queryset(self):
        return get_queryset_3(self)


    def get(self, request, *args, **kwargs):
        return get_2(self, request, *args, **kwargs)

#tested
class UpdateTODO(UpdateAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = TODOSerializer

    def get_todo_object_id(self):
        return get_todo_object_id_1(self)

    def get_object(self):
        return get_object_1(self)

    def update(self,request,*args,**kwargs):
       return update_1(self,request,*args,**kwargs)


class DeleteTODO(DestroyAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = TODOSerializer

    def get_todo_object_id(self):
        return get_todo_object_id_2(self)

    def get_object(self):

        return get_object_2(self)

    def destroy(self, request, *args, **kwargs):

        return destroy_2(self, request, *args, **kwargs)






#tested

class DoneTODO(APIView):

    permission_classes = [IsAuthenticated]
    serializer_class = TODOSerializer

    def get_todo_object_id(self):

        return get_todo_object_id_3(self)


    def get_object(self):

        return get_object_3(self)


    def post(self, request, *args, **kwargs):

        return post_6(self, request, *args, **kwargs)

#tested

class GetOneTODO(RetrieveAPIView):

    permission_classes = [IsAuthenticated]
    serializer_class = RecieveGroupTODOSerializer

    def get_queryset(self):
        return get_queryset_4(self)


    def get(self, request, *args, **kwargs):
        return get_3(self, request, *args, **kwargs)




