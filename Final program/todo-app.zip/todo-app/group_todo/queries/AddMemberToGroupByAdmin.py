from django.http import JsonResponse

from group_todo.models import Group, Member
from django.contrib.auth.models import User


def post_2(self, request, *args, **kwargs):

    req = request.data
    desired_user_id = req.get('user_id')
    target_group = req.get('target_group')
    data = {
        'member': desired_user_id,
        'group': target_group
    }
    serializer = self.serializer_class(data=data)
    serializer.is_valid(raise_exception=True)
    try:
        if User.objects.get(
                id=desired_user_id):
            if Member.objects.filter(member=desired_user_id, group=target_group).count() == 0:
                serializer.save()

                return JsonResponse(serializer.data)
            return JsonResponse({'msg': 'this user has already added !'}, status=400)
        return JsonResponse({'error': 'user does not exist!'}, status= 404)
    except Exception as e:
        return JsonResponse({'error': 'user object not found!'}, status= 404)