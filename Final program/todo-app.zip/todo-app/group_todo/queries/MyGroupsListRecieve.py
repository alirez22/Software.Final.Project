from group_todo.models import Member


def get_queryset_1(self):

    user = self.request.user
    qs = Member.objects.filter(member=user).select_related('group__admin')

    return qs