from django.http import JsonResponse

from group_todo.models import Group


def destroy_2(self, request, *args, **kwargs):
    admin = request.user
    req = request.data

    target_group = req.get('target_group')

    group_obj = Group.objects.get(id=target_group, admin=admin)

    group_obj.delete()
    return JsonResponse({'msg': 'the group successfully destroyed.'}, status=204)
