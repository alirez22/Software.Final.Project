from django.http import JsonResponse

from group_todo.models import Member


def get_queryset_2(self):

    id = self.request.GET.get('id')
    user = self.request.user
    try:
        if not Member.objects.get(group_id=id, member=user):
            return JsonResponse({'msg': 'only members can access!'})
        qs = Member.objects.filter(group_id=id)

        return qs

    except Exception as e:
        return JsonResponse({'error': e})
