from django.http import JsonResponse

from group_todo.models import Group


def post_3(self, format=None):
        admin = self.request.user
        req = self.request.data

        target_group = req.get('target_group')
        group_obj = Group.objects.get(id=target_group, admin=admin)
        group_obj.is_active = False
        group_obj.save()
        return JsonResponse({'msg': 'the group successfully disactivated.'}, status=200)
