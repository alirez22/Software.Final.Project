from datetime import datetime

from django.http import JsonResponse
from rest_framework import status

from msg.serializers import SaveNotificationSerializer
from todo.models import TODO
from todo.serializers import TODOSerializer


def post_5(self, request, *args, **kwargs):

    data = request.data
    owner = request.user
    json_data = {

        'title': data.get('title'),
        'discription': data.get('discription'),
        'date_wanna_be_done': data.get('date_wanna_be_done'),
        'owner': owner,
        'group': data.get('group'),
        'date_submitted': datetime.now()

    }
    # create todo objects
    serialized_todo = TODOSerializer(data=json_data)
    serialized_todo.is_valid(raise_exception=True)
    serialized_todo.save()
    serializer = self.serializer_class(data={'todo': serialized_todo.data['id'],

                                             'group': data.get('group')})

    serializer.is_valid(raise_exception=True)

    serializer.save()

    todo_obj = TODO.objects.get(id=serialized_todo.data['id'], )

    msg_serializer = SaveNotificationSerializer(data={'user': owner, 'todo_object': todo_obj.id})

    msg_serializer.is_valid(raise_exception=True)

    msg_serializer.save()

    return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)

