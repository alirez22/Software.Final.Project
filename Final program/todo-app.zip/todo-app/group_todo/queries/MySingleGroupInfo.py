from django.http import JsonResponse

from group_todo.models import Member


def get_1(self, request):
    id = request.GET.get('id')
    user = request.user
    try:
        qs = Member.objects.get(group_id=id, member=user)
        serializer = self.serializer_class(qs, many=False)
        return JsonResponse(serializer.data)
    except:
        return JsonResponse({'error': 'not exists!'}, status = 404)