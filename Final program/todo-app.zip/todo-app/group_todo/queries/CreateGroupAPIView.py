from django.http import JsonResponse

from group_todo.serializers import MemberCreateSerializer


def post_1(self, request, *args, **kwargs):
    user = request.user
    data = request.data
    input_data = {'group_name': data.get('group_name'),
                  'admin': user,
                  'group_category': data.get('group_category')}
    serializer = self.serializer_class(data=input_data)
    serializer.is_valid(raise_exception=True)
    serializer.save()
    member_serializer = MemberCreateSerializer(data={'group': serializer.data['id'], 'member': user})
    member_serializer.is_valid(raise_exception=True)
    member_serializer.save()
    return JsonResponse(serializer.data, status=201)