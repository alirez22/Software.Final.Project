from django.http import JsonResponse

from group_todo.models import GroupTODO
from todo.models import TODO


def get_todo_object_id_2(self):
    group_id = self.request.GET.get('group_id')
    todo_id = self.request.GET.get('todo_id')
    todo_object_id = GroupTODO.objects.get(group=group_id, id=todo_id)

    return todo_object_id.todo.id


def get_object_2(self):
    object = TODO.objects.get(id=self.get_todo_object_id())
    return object


def destroy_2(self, request, *args, **kwargs):
    instance = self.get_object()
    self.perform_destroy(instance)
    return JsonResponse({'msg': 'deleted'})