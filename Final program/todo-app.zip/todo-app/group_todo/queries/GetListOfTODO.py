from django.http import JsonResponse

from group_todo.models import GroupTODO, Member


def get_queryset_3(self):

    user = self.request.user
    group_id = self.request.GET.get('group_id')
    qs = GroupTODO.objects.filter(group=group_id)
    return qs

def get_2(self, request, *args, **kwargs):

    user = request.user
    group_id = self.request.GET.get('group_id')
    qs = self.get_queryset()
    if Member.objects.filter(member=user , group = group_id).count() >= 1:
        serializer = self.serializer_class(data = qs, many = True)
        serializer.is_valid()
        return JsonResponse(serializer.data, safe=False)
    return JsonResponse({'msg':'only group member can see todo list!'})
