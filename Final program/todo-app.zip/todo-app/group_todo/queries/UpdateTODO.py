from django.http import JsonResponse

from group_todo.models import GroupTODO
from todo.models import TODO


def get_todo_object_id_1(self):
    group_id = self.request.GET.get('group_id')
    todo_id = self.request.GET.get('todo_id')
    todo_object_id = GroupTODO.objects.get(group=group_id, id=todo_id)

    return todo_object_id.todo.id


def get_object_1(self):
    object = TODO.objects.get(id=self.get_todo_object_id())
    return object


def update_1(self, request, *args, **kwargs):

    data = request.data
    instance = self.get_object()
    instance.title = data.get('title', instance.title)
    instance.discription = data.get('discription', instance.discription)

    d = {
        'title': instance.title,
        'discription': instance.discription,
    }

    serializer = self.get_serializer(instance, data=d, partial=True)

    serializer.is_valid(raise_exception=True)

    self.perform_update(serializer)

    return JsonResponse(serializer.data, status=200)
