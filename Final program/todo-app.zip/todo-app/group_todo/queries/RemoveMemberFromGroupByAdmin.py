from django.http import JsonResponse

from group_todo.models import Member, Group
from django.contrib.auth.models import User


def destroy_1(self, request, *args, **kwargs):

    req = request.data
    desired_user_id = req.get('user_id')
    target_group = req.get('target_group')

    try:
        if User.objects.get(id=desired_user_id):
            target_member = Member.objects.filter(member=desired_user_id, group=target_group)
            if target_member.count() == 1:
                target_member.delete()

                return JsonResponse({'msg': 'target user successfully removed from group!'}, status = 200)
            return JsonResponse({'msg': 'this user has already removed !'}, status = 400)

    except Exception as e:
        return JsonResponse({'error': 'the user not found!'}, status= 404)
