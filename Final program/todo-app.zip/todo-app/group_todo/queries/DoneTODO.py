from datetime import datetime

from django.http import JsonResponse

from group_todo.models import GroupTODO
from todo.models import TODO


def get_todo_object_id_3(self):
    group_id = self.request.GET.get('group_id')
    todo_id = self.request.GET.get('todo_id')
    todo_object_id = GroupTODO.objects.get(group=group_id, id=todo_id)

    return todo_object_id.todo.id


def get_object_3(self):
    object = TODO.objects.get(id=self.get_todo_object_id())
    return object


def post_6(self, request, *args, **kwargs):

        try:
            instance = self.get_object()
            instance.is_done = True
            instance.date_done = datetime.datetime.now()
            instance.save()

            return JsonResponse({'msg':'done!'}, status=200)
        except Exception as e:
            print(e)
            return JsonResponse({'msg':'not found!'}, status = 404)