#create a permission class for the user
from django.http import JsonResponse
from rest_framework import permissions

from group_todo.models import Group


class IsGroupAdmin(permissions.BasePermission):

    def has_permission(self, request, view):
        user = request.user
        group_id = request.data.get('target_group')
        try:
            if Group.objects.get(id=group_id, admin=user):

                return True
        except Exception as e:
            return False
