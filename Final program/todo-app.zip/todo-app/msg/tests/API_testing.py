from django.test import TestCase
from rest_framework.test import APIClient
from todo.models import *
from django.contrib.auth.models import User


class SubmitAPITesting(TestCase ):

    client = APIClient()




