from django.test import TestCase

from msg.models import Notification
from todo.models import *
from django.contrib.auth.models import User


class SaveNotification(TestCase):

    def setUp(self) -> None:
        self.user = User.objects.filter().first()
        self.todo = TODO.objects.filter(owner= self.user).first()
        object = Notification.objects.create(user = self.user, todo_object= self.todo)
        self.object = object

    def test_saved(self):

        self.assertEqual(self.object.user , self.user)
        self.assertEqual(self.object.todo_object , self.todo)


class DeleteNotification(TestCase):

    def setUp(self) -> None:

        self.user = User.objects.filter().first()
        self.todo = TODO.objects.filter(owner=self.user).first()
        Notification.objects.create(user=self.user, todo_object=self.todo)



    def test_deleted(self):

        object = Notification.objects.get(user=self.user, todo_object=self.todo)
        object.delete()







