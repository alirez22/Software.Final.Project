
def send(l):
    subjects = []
    for x in l:
        email = x.user.email
        subject = { 'title' : x.todo_object.title, 'discription': x.todo_object.discription, 'email':email}
        subjects.append(subject)
    print(subjects)


