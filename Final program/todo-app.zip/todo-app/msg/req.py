import requests
import os

def requ():
    LH = os.environ.get('LOCALHOST')
    requests.post(f'{LH}/msg/msg/send/')