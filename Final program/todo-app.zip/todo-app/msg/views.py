from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework.generics import CreateAPIView, UpdateAPIView, RetrieveAPIView, DestroyAPIView, ListAPIView
from rest_framework.permissions import *
from rest_framework.views import APIView
from datetime import datetime
from msg.models import Notification
from msg.sending_msg_function import send
from msg.serializers import SaveNotificationSerializer



class SendMSGView(APIView):
    def post(self, format = None) -> None:
        today = datetime.now()
        target_objects = Notification.objects.filter(todo_object__date_done=today)
        list_of_objects = target_objects.values('user','todo_object__title','todo_object__discription')
        # send msg
        response = send(list_of_objects)
        return Response(response)






