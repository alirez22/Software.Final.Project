from rest_framework import serializers
from msg.models import Notification
from todo.models import TODO
from django.contrib.auth.models import User


class SaveNotificationSerializer(serializers.ModelSerializer):

    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    todo_object = serializers.PrimaryKeyRelatedField(queryset=TODO.objects.all())

    class Meta:
        model = Notification
        fields = '__all__'
