from django.conf import settings
from django.core.cache.backends.base import DEFAULT_TIMEOUT
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from rest_framework.generics import CreateAPIView, UpdateAPIView, RetrieveAPIView, DestroyAPIView, ListAPIView
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
import redis
from todo.queries import *
from todo.serializers import TODOSerializer


#a view for submitting a new to do form
CACHE_TTL = getattr(settings, 'CACHE_TTL', DEFAULT_TIMEOUT)

class BulkSubmit:
    pass

class Submit(CreateAPIView):

    serializer_class = TODOSerializer
    permission_classes = [IsAuthenticated]
    queryset = TODO.objects.all()

    def post(self, request, *args, **kwargs):
        return todo_submission(request,self)


#getting a list of your to do s
class GetList(ListAPIView):

    serializer_class = TODOSerializer
    permission_classes = [IsAuthenticated,]


    def get_queryset(self):
        return todo_list(self)


#getting one of your to do s with its id
class GetOne(RetrieveAPIView):

    serializer_class = TODOSerializer
    permission_classes = [IsAuthenticated]


    def retrieve(self, request, *args, **kwargs):
        return todo_one(request, self)


#updating your to do object (title, discription)
class UpdateTODO(UpdateAPIView):

    serializer_class = TODOSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return get_todo_object_update(self)


    def update(self, request, *args, **kwargs):
        return todo_update(request,self)



#delete to do object
class DeleteTODO(DestroyAPIView):

    serializer_class = TODOSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return get_todo_object_delete(self)


    def destroy(self, request, *args, **kwargs):
        return todo_delete(self)



#change is done status with id
class IsDone(APIView):
    def post(self,format = None):
        return todo_done(self)

