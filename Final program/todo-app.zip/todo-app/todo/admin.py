from django.contrib import admin

# Register your models here.
from todo.models import TODO

admin.site.register(TODO)