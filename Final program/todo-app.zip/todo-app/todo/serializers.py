from rest_framework import serializers

from todo.models import TODO
from django.contrib.auth.models import User

class OwnerSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class TODOSerializer(serializers.ModelSerializer):


    id = serializers.CharField(read_only=True)
    owner = serializers.PrimaryKeyRelatedField(queryset=User.objects.all())
    title = serializers.CharField(max_length=100)
    discription = serializers.CharField()
    date_submitted = serializers.DateTimeField(required=False)
    date_done = serializers.DateTimeField(required=False)
    is_done = serializers.BooleanField(required=False)
    date_wanna_be_done = serializers.DateField(required=False)

    class Meta:
        model = TODO

        fields = ('id',
                'owner',
                'title',
                'discription',
                'date_submitted',
                'date_done',
                'is_done',
                'date_wanna_be_done')

