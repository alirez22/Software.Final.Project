import datetime

from django.conf import settings
from django.core.cache import cache
import redis
from django.http import JsonResponse
from rest_framework import status

from msg.serializers import SaveNotificationSerializer
from todo.models import TODO

redis_instance = redis.StrictRedis(host=settings.REDIS_HOST,
                                  port=settings.REDIS_PORT, db=0)

import time

def todo_submission(request,self,*args, **kwargs):
    data = request.data
    owner = request.user
    json_data = {

        'title': data.get('title'),
        'discription': data.get('discription'),
        'date_wanna_be_done': data.get('date_wanna_be_done'),
        'owner': owner,
        'date_submitted':datetime.datetime.now(),

    }
    print(datetime.datetime.now())
    serializer = self.serializer_class(data=json_data)

    serializer.is_valid(raise_exception=True)

    serializer.save()



    todo_obj = TODO.objects.get(id = serializer.data['id'])

    msg_serializer = SaveNotificationSerializer(data= { 'user':owner, 'todo_object': todo_obj.id})

    msg_serializer.is_valid(raise_exception=True)

    msg_serializer.save()

    return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)

def get_todo_object_update(self):

    id = self.request.GET.get('id')
    obj = TODO.objects.get(id=id)
    return obj


def get_todo_object_delete(self):
    queryset = TODO.objects.filter(owner=self.request.user, id=self.request.GET.get('pk'))

    return queryset

def todo_list(self):
    user = self.request.user
    is_done = self.request.GET.get('is_done')
    todo = TODO.objects.filter(owner=user,is_done = is_done).select_related('owner')


    return todo


def todo_one(request, self):
    try:
        user = request.user
        id = request.GET.get('id')
        todo = TODO.objects.get(owner=user, id=id)
        serializer = self.serializer_class(todo)
        return JsonResponse(serializer.data, status=200)
    except Exception as e:
        print(e)
        return JsonResponse({'error': 'there is no more any object with this id !'}, status=204)



def todo_update(request, self):
    data = request.data
    instance = self.get_object()
    instance.title = data.get('title', instance.title)
    instance.discription = data.get('discription', instance.discription)

    d = {
        'title': instance.title,
        'discription': instance.discription,
    }

    serializer = self.get_serializer(instance, data=d, partial=True)

    serializer.is_valid(raise_exception=True)

    self.perform_update(serializer)

    return JsonResponse(serializer.data, status=200)

def todo_delete(self):

    instance = self.get_object()
    self.perform_destroy(instance)
    return JsonResponse({'msg': 'deleted'})


def todo_done(self):

    id = self.request.GET.get('id')
    user = self.request.user
    if not user:
        return JsonResponse({'msg': 'not authorized!'})
    is_done = self.request.data.get('is_done')
    object = TODO.objects.get(id=id, owner=user)
    object.is_done = is_done
    if object.is_done == True:
        object.date_done = datetime.datetime.now()
        object.save()
        return JsonResponse({'msg': 'object updated!, done ! '}, status=200)
    elif object.is_done == False:
        object.save()
        return JsonResponse({'msg': 'object updated!, not done ! '}, status=200)

