from django.test import TestCase

from todo.models import *
from django.contrib.auth.models import User


class SubmitTesting(TestCase):



    def setUp(self) -> None:

        owner = User.objects.all().first().id

        TODO.objects.create(title='ddd', discription='fegshde',owner_id=owner)

    def test_saved(self):

        object = TODO.objects.get(title = 'ddd')

        self.assertEqual(object.title, 'ddd')


class GetListTesting(TestCase):



    def setUp(self) -> None:

        self.owner = User.objects.all().first()

    def test_get_list(self):

        todo = TODO.objects.filter(owner=self.owner)

        self.assertGreaterEqual(todo.count(), 0)


class GetOneTesting(TestCase):



    def setUp(self) -> None:

        self.owner = User.objects.all().first()

    def test_get_list(self):

        todo = TODO.objects.filter(owner=self.owner, id = 25)

        self.assertGreaterEqual(todo.count(), 0)



class UpdateTODOTesting(TestCase):

    def setUp(self) -> None:

        self.owner = User.objects.all().first()


    def test_get_list(self):

        todo = TODO.objects.filter(owner=self.owner).first()

        todo.title = 'b'

        todo.save()

        self.assertEqual(todo.title, 'b')

        self.assertEqual(TODO.objects.filter(owner=self.owner).first().title , 'b')


class DeleteTODOTesting(TestCase):

    def setUp(self) -> None:

        self.owner = User.objects.all().first()

    def test_delete(self):


        todo = TODO.objects.filter(owner=self.owner).first()

        id = todo.id

        todo.delete()

        self.assertNotEqual(todo.id , id)


class IsDoneTesting(TestCase):

    def setUp(self) -> None:

        self.owner = User.objects.all().first()

    def test_done(self):

        todo = TODO.objects.filter(owner=self.owner).first()

        todo.is_done = True

        todo.save()

        self.assertEqual(todo.is_done , True)
