from django.test import TestCase
from rest_framework.test import APIClient

from todo.models import *
from django.contrib.auth.models import User


class SubmitAPITesting(TestCase ):

    client = APIClient()

    def setUp(self) -> None:
        access_token = self.client.post('/user/api/token/', {'username': 'abolfazl832',
                                                         'password': 'ghurgegrhfe4'},
                                    format='json').data['access']

        self.response = self.client.post('/todo/submit/',
                                    {'title':'x','discription':'rgsyyyyyy', 'date_wanna_be_done':'2023-06-09'},
                                    HTTP_AUTHORIZATION= 'Bearer ' + access_token,
                                    format= 'json')

    def test_saved(self):

            self.assertEqual(self.response.status_code, 201)


class GetAPITesting(TestCase):
    def setUp(self) -> None:
        access_token = self.client.post('/user/api/token/', {'username': 'abolfazl832',
                                                             'password': 'ghurgegrhfe4'},
                                        format='json').data['access']

        self.response = self.client.get('/todo/get_todo_list/',

                                         HTTP_AUTHORIZATION='Bearer ' + access_token,
                                         format='json')

    def test_saved(self):
        self.assertEqual(self.response.status_code, 200)





class GetOneAPITesting(TestCase):
    def setUp(self) -> None:
        access_token = self.client.post('/user/api/token/', {'username': 'abolfazl832',
                                                             'password': 'ghurgegrhfe4'},
                                        format='json').data['access']
        user = User.objects.get(username = 'abolfazl832')
        todo = TODO.objects.filter(owner=user).first()
        id = todo.id

        self.response = self.client.get('/todo/get_todo_one/?id=26',

                                        HTTP_AUTHORIZATION='Bearer ' + access_token,
                                        format='json')

    def test_saved(self):
        self.assertEqual(self.response.status_code, 200)




class UpdateTODOAPITesting(TestCase):
    pass




class DeleteTODOAPITesting(TestCase):
    pass




class IsDoneAPITesting(TestCase):
    pass

