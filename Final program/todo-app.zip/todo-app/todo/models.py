from django.db import models
import datetime
from django.contrib.auth.models import User


class TODO(models.Model):

    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='owner_obj')
    title = models.CharField(default=None, max_length=100)
    discription = models.TextField()
    date_submitted = models.DateTimeField(null = True)
    date_done = models.DateTimeField(null=True)
    date_wanna_be_done = models.DateField(default=None,null=True)
    is_done = models.BooleanField(default=False)

    def __str__(self):

        return self.title
