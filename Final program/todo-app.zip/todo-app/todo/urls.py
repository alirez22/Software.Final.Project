from django.urls import path
from .views import Submit,DeleteTODO,GetList,IsDone,UpdateTODO,GetOne
from django.views.decorators.cache import cache_page

urlpatterns = [
    path('submit/',Submit.as_view()),
    path('get_todo_list/',GetList.as_view()),
    path('get_todo_one/',GetOne.as_view()),
    path('is_done/', IsDone.as_view()),
    path('delete_todo/',DeleteTODO.as_view()),
]
