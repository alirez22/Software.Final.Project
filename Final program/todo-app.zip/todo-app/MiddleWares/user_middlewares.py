import jwt
from django.conf import LazySettings
from django.http import JsonResponse
from django.utils.deprecation import MiddlewareMixin

from django.contrib.auth.models import User
from user.views import DeActivate


settings = LazySettings()

class IsActiveMiddleware(MiddlewareMixin):

    WHITELISTED_URLS = [
        "/user/get_info/",

    ]
    def process_request(self, request,view_func = DeActivate):

        if request.path in self.WHITELISTED_URLS:


            token = request.META.get('HTTP_AUTHORIZATION')

            decoded_token = jwt.decode(token.split(' ')[1],key = settings.SECRET_KEY, algorithms=['HS256'])

            user = User.objects.get(id = decoded_token['user_id'])

            if user.is_active == False:
                return JsonResponse({'msg':'you are not able to access this component cause you are not active, please chack your activity status'},
                                   status=401)
            print(user.is_active)
            return ''




